#!/usr/bin/env python3

import rospy
from turtlesim.srv import Spawn, SpawnRequest

def spawn_turtle(x, y, theta, name):
    rospy.wait_for_service('spawn')
    try:
        spawn_turtle = rospy.ServiceProxy('spawn', Spawn)
        spawn_turtle(x, y, theta, name)
    except rospy.ServiceException as e:
        rospy.logerr("Service call failed: %s" % e)

if __name__ == '__main__':
    rospy.init_node('draw_shapes', anonymous=True)

    # Coordinates for drawing "I"
    I_coords = [
        (1.0, 9.0),  # top
        (1.0, 8.0),
        (1.0, 7.0),
        (1.0, 6.0),
        (1.0, 5.0),  # middle
        (1.0, 4.0),
        (1.0, 3.0),
        (1.0, 2.0),
        (1.0, 1.0)   # bottom
    ]

    # Coordinates for drawing "Δ"
    delta_coords = [
        (4.0, 3.0),  # bottom left
        (4.5, 4.0),
        (5.0, 5.0),
        (5.5, 6.0),
        (6.0, 7.0),  # top
        (6.5, 6.0),
        (7.0, 5.0),
        (7.5, 4.0),
        (8.0, 3.0),  # bottom right
        (7.0, 3.0),
        (6.0, 3.0),
        (5.0, 3.0)
    ]

    # Spawn turtles for "I"
    for i, (x, y) in enumerate(I_coords):
        spawn_turtle(x, y, 0, f'turtle_I_{i+1}')

    # Spawn turtles for "Δ"
    for i, (x, y) in enumerate(delta_coords):
        spawn_turtle(x, y, 0, f'turtle_delta_{i+1}')

    rospy.spin()

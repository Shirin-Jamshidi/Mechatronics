#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
import sys, termios, tty, curses

def getKey(stdscr):
    key = stdscr.getch()
    return key

def control_turtle(stdscr):
    rospy.init_node('turtle_controller', anonymous=True)
    pub_dict = {}
    rate = rospy.Rate(10)  # 10 Hz

    # Create publishers for each turtle in the "I" shape
    for turtle_name in turtle_names:
        pub_dict[turtle_name] = rospy.Publisher(f'/{turtle_name}/cmd_vel', Twist, queue_size=10)

    twist = Twist()
    speed = 1.0

    while not rospy.is_shutdown():
        key = getKey(stdscr)
        twist = Twist()

        if key == curses.KEY_UP:
            twist.linear.y = speed
        elif key == curses.KEY_DOWN:
            twist.linear.y = -speed
        elif key == curses.KEY_LEFT:
            twist.linear.x = -speed
        elif key == curses.KEY_RIGHT:
            twist.linear.x = speed
        else:
            twist.linear.x = 0
            twist.angular.z = 0

        for pub in pub_dict.values():
            pub.publish(twist)

        rate.sleep()

if __name__ == '__main__':
    settings = termios.tcgetattr(sys.stdin)
    rospy.on_shutdown(lambda: termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings))

    try:
        turtle_names = [f'turtle_I_{i+1}' for i in range(9)]  # Update with the turtle names for the "I" shape
        curses.wrapper(control_turtle)
    except rospy.ROSInterruptException:
        pass

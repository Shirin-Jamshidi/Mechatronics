#!/usr/bin/env python3

#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from turtlesim.srv import Spawn, SpawnRequest
import threading

def rotate_turtle(turtle_name):
    pub = rospy.Publisher(f'/{turtle_name}/cmd_vel', Twist, queue_size=10)
    rate = rospy.Rate(10)  # 10 Hz
    twist = Twist()
    twist.angular.z = 1.0  # Rotate counter-clockwise

    while not rospy.is_shutdown():
        pub.publish(twist)
        rate.sleep()

def rotate_all_turtles(turtles):
    threads = []
    for turtle in turtles:
        thread = threading.Thread(target=rotate_turtle, args=(turtle,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

if __name__ == '__main__':
    rospy.init_node('rotating_node', anonymous=True)

    # List of all turtles to rotate
    turtles = ['turtle1', 'turtle_I_1', 'turtle_I_2', 'turtle_I_3', 'turtle_I_4', 'turtle_I_5', 'turtle_I_6', 'turtle_I_7', 'turtle_I_8', 'turtle_I_9',
               'turtle_delta_1', 'turtle_delta_2', 'turtle_delta_3', 'turtle_delta_4', 'turtle_delta_5', 'turtle_delta_6', 'turtle_delta_7', 'turtle_delta_8', 'turtle_delta_9', 'turtle_delta_10', 'turtle_delta_11', 'turtle_delta_12']

    # Start rotating all turtles simultaneously
    rotate_all_turtles(turtles)


% Define symbolic variables
syms q1 q2 q3 real;

% Jacobian matrix
J = [[-sin(q3) cos(q1) cos(q2)*sin(q3)];
    [cos(q3) sin(q1) -cos(q2)*cos(q3)];
    [0 cos(q1)*cos(q2)+sin(q1)*sin(q2) cos(q1)*sin(q3)*sin(q2)-sin(q1)*sin(q2)*sin(q3)]];

% Compute the determinant of the Jacobian matrix
det_J = det(J);

% Find the singularities (where det(J) = 0)
singularities = solve(det_J == 0, [q1 q2 q3]);
disp(singularities);

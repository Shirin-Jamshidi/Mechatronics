#include <iostream>
#include <cmath>
#include <thread>
#include <chrono>
#include <vector>


using namespace std;

void func(int number, int delay, const std::string& word) {
  for (int i = 0; i < number; ++i) {
    std::cout << word << std::endl;
    std::this_thread::sleep_for(std::chrono::seconds(delay));
  }  
}


int main() {
    
    // problem 1
    int a = 4;
    float b = 1.6;

    float addition = a + b;
    float subtraction = a - b;
    float multiplication = a * b;
    float division = a / b;
    float exponentiation = std::pow(a, b);

    std::cout << "Addition: " << addition << std::endl;
    std::cout << "Subtraction: " << subtraction << std::endl;
    std::cout << "Multiplication: " << multiplication << std::endl;
    std::cout << "Division: " << division << std::endl;
    std::cout << "Exponentiation: " << exponentiation << std::endl;
    
    // problem 2
    int age; 
    std::cout << "How old are you? "; 
    std::cin >> age; 
    
    if (age < 18) {
      std::cout << "Minor!"<< std::endl;
    } else if (age > 65) {
      std::cout << "Senior!"<< std::endl;
    } else {
      std::cout << "Adult!"<< std::endl;
    }

    // problem 3
    int n = 10;
    int c = 1, d = 1;
    
    for (int i = 0; i < n; ++i) {
        std::cout << c << " ";
        int temp = c;
        c = d;
        d = temp + d;
    }
    std::cout << "\n";
    
    // problem 4
    int number = 6;
    int delay = 4;
    std::string word = "salam!";
    func(number, delay, word);
    
    return 0;
}